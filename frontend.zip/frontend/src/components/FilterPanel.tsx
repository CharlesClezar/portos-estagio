
import React, { useState } from 'react';
import { Calendar, Filter, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ApiFilters } from '@/types/port';
import PortAutocomplete from './PortAutocomplete';
import { Port } from '@/types/port';

interface FilterPanelProps {
  filters: ApiFilters;
  onFiltersChange: (filters: ApiFilters) => void;
  onApplyFilters: () => void;
  isLoading?: boolean;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
  filters,
  onFiltersChange,
  onApplyFilters,
  isLoading = false
}) => {
  const [selectedPort, setSelectedPort] = useState<Port | null>(null);

  const handlePortSelect = (port: Port | null) => {
    setSelectedPort(port);
    onFiltersChange({
      ...filters,
      portCode: port?.code || undefined,
      portName: port?.name || undefined,
    });
  };

  const handleDateChange = (field: 'startDate' | 'endDate', value: string) => {
    onFiltersChange({
      ...filters,
      [field]: value || undefined,
    });
  };

  const handleSelectChange = (field: keyof ApiFilters, value: string) => {
    onFiltersChange({
      ...filters,
      [field]: value || undefined,
    });
  };

  const handleReset = () => {
    setSelectedPort(null);
    onFiltersChange({
      sortBy: 'date',
      sortOrder: 'desc',
      limit: 100,
    });
  };

  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <Filter className="h-5 w-5" />
          Filtros de Pesquisa
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {/* Porto */}
          <div className="space-y-2">
            <Label>Porto</Label>
            <PortAutocomplete
              onSelectPort={handlePortSelect}
              selectedPort={selectedPort}
              placeholder="Selecione um porto..."
            />
          </div>

          {/* Data Inicial */}
          <div className="space-y-2">
            <Label htmlFor="startDate">Data Inicial</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                id="startDate"
                type="date"
                value={filters.startDate || thirtyDaysAgo}
                onChange={(e) => handleDateChange('startDate', e.target.value)}
                className="pl-10"
                max={today}
              />
            </div>
          </div>

          {/* Data Final */}
          <div className="space-y-2">
            <Label htmlFor="endDate">Data Final</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                id="endDate"
                type="date"
                value={filters.endDate || today}
                onChange={(e) => handleDateChange('endDate', e.target.value)}
                className="pl-10"
                max={today}
                min={filters.startDate}
              />
            </div>
          </div>

          {/* Tipo de Embarcação */}
          <div className="space-y-2">
            <Label>Tipo de Embarcação</Label>
            <Select
              value={filters.vesselType || 'all'}
              onValueChange={(value) => handleSelectChange('vesselType', value === 'all' ? '' : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todos os tipos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="container">Porta-contêineres</SelectItem>
                <SelectItem value="bulk">Graneleiros</SelectItem>
                <SelectItem value="tanker">Navios-tanque</SelectItem>
                <SelectItem value="other">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Ordenar Por */}
          <div className="space-y-2">
            <Label>Ordenar Por</Label>
            <Select
              value={filters.sortBy || 'date'}
              onValueChange={(value) => handleSelectChange('sortBy', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Data</SelectItem>
                <SelectItem value="volume">Volume Total</SelectItem>
                <SelectItem value="vesselCalls">Chamadas de Embarcação</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Ordem */}
          <div className="space-y-2">
            <Label>Ordem</Label>
            <Select
              value={filters.sortOrder || 'desc'}
              onValueChange={(value) => handleSelectChange('sortOrder', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="desc">Decrescente</SelectItem>
                <SelectItem value="asc">Crescente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Limite */}
          <div className="space-y-2">
            <Label>Limite de Resultados</Label>
            <Select
              value={filters.limit?.toString() || '100'}
              onValueChange={(value) => handleSelectChange('limit', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
                <SelectItem value="200">200</SelectItem>
                <SelectItem value="500">500</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="flex gap-3 pt-4 border-t">
          <Button
            onClick={onApplyFilters}
            disabled={isLoading}
            className="flex-1 sm:flex-none"
          >
            {isLoading ? (
              <>
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                Carregando...
              </>
            ) : (
              <>
                <Filter className="h-4 w-4 mr-2" />
                Aplicar Filtros
              </>
            )}
          </Button>
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Limpar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterPanel;
