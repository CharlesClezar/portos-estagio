
import { Port, PortActivity, PortRanking, ApiFilters } from '@/types/port';

// Mock data para demonstração
const mockPorts: Port[] = [
  { id: '1', name: 'Shanghai', code: 'CNSHA', country: 'China', latitude: 31.2304, longitude: 121.4737 },
  { id: '2', name: 'Singapore', code: 'SGSIN', country: 'Singapore', latitude: 1.2966, longitude: 103.7764 },
  { id: '3', name: 'Ningbo-Zhoushan', code: 'CNNGB', country: 'China', latitude: 29.8683, longitude: 121.544 },
  { id: '4', name: 'Shenzhen', code: 'CNSZN', country: 'China', latitude: 22.5431, longitude: 114.0579 },
  { id: '5', name: 'Guangzhou Harbor', code: 'CNGZH', country: 'China', latitude: 23.1291, longitude: 113.2644 },
  { id: '6', name: 'Busan', code: 'KRPUS', country: 'South Korea', latitude: 35.1796, longitude: 129.0756 },
  { id: '7', name: 'Hong Kong', code: 'HKHKG', country: 'Hong Kong', latitude: 22.3193, longitude: 114.1694 },
  { id: '8', name: 'Qingdao', code: 'CNTAO', country: 'China', latitude: 36.0986, longitude: 120.3719 },
  { id: '9', name: 'Los Angeles', code: 'USLAX', country: 'United States', latitude: 33.7701, longitude: -118.1937 },
  { id: '10', name: 'Long Beach', code: 'USLGB', country: 'United States', latitude: 33.7701, longitude: -118.1937 },
  { id: '11', name: 'Rotterdam', code: 'NLRTM', country: 'Netherlands', latitude: 51.9225, longitude: 4.47917 },
  { id: '12', name: 'Antwerp', code: 'BEANR', country: 'Belgium', latitude: 51.2993, longitude: 4.4014 },
];

const generateMockActivity = (port: Port, date: Date): PortActivity => {
  const baseVolume = Math.random() * 50000 + 10000;
  const vesselCalls = Math.floor(Math.random() * 50) + 10;
  
  return {
    id: `${port.id}-${date.toISOString().split('T')[0]}`,
    portId: port.id,
    portName: port.name,
    portCode: port.code,
    date: date.toISOString().split('T')[0],
    vesselCalls,
    containerVolume: Math.floor(baseVolume * 0.6),
    bulkVolume: Math.floor(baseVolume * 0.25),
    liquidVolume: Math.floor(baseVolume * 0.15),
    totalVolume: Math.floor(baseVolume),
    vesselTypes: {
      container: Math.floor(vesselCalls * 0.4),
      bulk: Math.floor(vesselCalls * 0.3),
      tanker: Math.floor(vesselCalls * 0.2),
      other: Math.floor(vesselCalls * 0.1),
    }
  };
};

export const portApi = {
  async searchPorts(query: string): Promise<Port[]> {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simular delay da API
    
    return mockPorts.filter(port => 
      port.name.toLowerCase().includes(query.toLowerCase()) ||
      port.code.toLowerCase().includes(query.toLowerCase()) ||
      port.country.toLowerCase().includes(query.toLowerCase())
    );
  },

  async getPortActivity(filters: ApiFilters): Promise<PortActivity[]> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const startDate = filters.startDate ? new Date(filters.startDate) : new Date('2024-01-01');
    const endDate = filters.endDate ? new Date(filters.endDate) : new Date('2024-12-31');
    
    let selectedPorts = mockPorts;
    if (filters.portCode) {
      selectedPorts = mockPorts.filter(port => port.code === filters.portCode);
    }
    
    const activities: PortActivity[] = [];
    
    selectedPorts.forEach(port => {
      const currentDate = new Date(startDate);
      while (currentDate <= endDate) {
        activities.push(generateMockActivity(port, new Date(currentDate)));
        currentDate.setDate(currentDate.getDate() + 1);
      }
    });
    
    // Aplicar ordenação
    if (filters.sortBy) {
      activities.sort((a, b) => {
        let aValue: any, bValue: any;
        switch (filters.sortBy) {
          case 'date':
            aValue = new Date(a.date);
            bValue = new Date(b.date);
            break;
          case 'volume':
            aValue = a.totalVolume;
            bValue = b.totalVolume;
            break;
          case 'vesselCalls':
            aValue = a.vesselCalls;
            bValue = b.vesselCalls;
            break;
          default:
            return 0;
        }
        
        if (filters.sortOrder === 'desc') {
          return bValue > aValue ? 1 : -1;
        }
        return aValue > bValue ? 1 : -1;
      });
    }
    
    return activities.slice(0, filters.limit || 100);
  },

  async getTopPorts(type: 'import' | 'export' = 'import', limit: number = 10): Promise<PortRanking[]> {
    await new Promise(resolve => setTimeout(resolve, 400));
    
    const rankings: PortRanking[] = mockPorts.map((port, index) => ({
      portId: port.id,
      portName: port.name,
      portCode: port.code,
      totalVolume: Math.floor(Math.random() * 1000000) + 100000,
      rank: index + 1,
      country: port.country,
    }));
    
    rankings.sort((a, b) => b.totalVolume - a.totalVolume);
    rankings.forEach((port, index) => {
      port.rank = index + 1;
    });
    
    return rankings.slice(0, limit);
  }
};
