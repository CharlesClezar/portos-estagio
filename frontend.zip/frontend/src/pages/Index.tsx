
import React, { useState, useEffect } from 'react';
import { Ship, BarChart3, TrendingUp, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import FilterPanel from '@/components/FilterPanel';
import DataTable from '@/components/DataTable';
import Charts from '@/components/Charts';
import { PortActivity, PortRanking, ApiFilters } from '@/types/port';
import { portApi } from '@/services/portApi';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const [activityData, setActivityData] = useState<PortActivity[]>([]);
  const [rankingData, setRankingData] = useState<PortRanking[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFilters] = useState<ApiFilters>({
    sortBy: 'date',
    sortOrder: 'desc',
    limit: 100,
  });

  const { toast } = useToast();

  // Carregar dados iniciais
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [activities, rankings] = await Promise.all([
        portApi.getPortActivity(filters),
        portApi.getTopPorts('import', 10),
      ]);
      setActivityData(activities);
      setRankingData(rankings);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Houve um problema ao carregar os dados. Tente novamente.",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  const handleApplyFilters = async () => {
    setIsLoading(true);
    try {
      const activities = await portApi.getPortActivity(filters);
      setActivityData(activities);
      
      toast({
        title: "Filtros aplicados",
        description: `${activities.length} registros encontrados.`,
      });
    } catch (error) {
      console.error('Erro ao aplicar filtros:', error);
      toast({
        title: "Erro ao aplicar filtros",
        description: "Houve um problema ao aplicar os filtros. Tente novamente.",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  // Calcular estatísticas resumidas
  const stats = React.useMemo(() => {
    const totalVolume = activityData.reduce((sum, item) => sum + item.totalVolume, 0);
    const totalCalls = activityData.reduce((sum, item) => sum + item.vesselCalls, 0);
    const uniquePorts = new Set(activityData.map(item => item.portCode)).size;
    const avgVolume = activityData.length > 0 ? totalVolume / activityData.length : 0;

    return {
      totalVolume,
      totalCalls,
      uniquePorts,
      avgVolume,
      totalRecords: activityData.length,
    };
  }, [activityData]);

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('pt-BR').format(value);
  };

  const formatLargeNumber = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return formatNumber(value);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-lg">
              <Ship className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Sistema de Análise Portuária
              </h1>
              <p className="text-gray-600 mt-1">
                Monitoramento e análise de atividades portuárias globais
              </p>
            </div>
          </div>

          {/* Estatísticas Resumidas */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 mb-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Volume Total</p>
                    <p className="text-lg font-bold text-blue-600">
                      {formatLargeNumber(stats.totalVolume)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Ship className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Chamadas</p>
                    <p className="text-lg font-bold text-green-600">
                      {formatNumber(stats.totalCalls)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-gray-600">Portos</p>
                    <p className="text-lg font-bold text-orange-600">
                      {stats.uniquePorts}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-gray-600">Média Volume</p>
                    <p className="text-lg font-bold text-purple-600">
                      {formatLargeNumber(stats.avgVolume)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">
                    Registros: {stats.totalRecords}
                  </Badge>
                </div>
                <div className="mt-2">
                  <p className="text-xs text-gray-500">
                    Última atualização: {new Date().toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Filtros */}
        <div className="mb-6">
          <FilterPanel
            filters={filters}
            onFiltersChange={setFilters}
            onApplyFilters={handleApplyFilters}
            isLoading={isLoading}
          />
        </div>

        {/* Conteúdo Principal */}
        <Tabs defaultValue="charts" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:w-400">
            <TabsTrigger value="charts" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Gráficos
            </TabsTrigger>
            <TabsTrigger value="table" className="flex items-center gap-2">
              <Ship className="h-4 w-4" />
              Tabela de Dados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="charts" className="space-y-6">
            <Charts
              activityData={activityData}
              rankingData={rankingData}
              isLoading={isLoading}
            />
          </TabsContent>

          <TabsContent value="table" className="space-y-6">
            <DataTable data={activityData} isLoading={isLoading} />
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="text-center text-sm text-gray-500">
            <p>
              Dados fornecidos por: FMI • Última atualização: 11/11/2024
            </p>
            <p className="mt-1">
              Sistema desenvolvido para análise de atividades portuárias globais
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
